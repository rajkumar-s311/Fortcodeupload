#In trimColor get , you are returning trimColor. But i choose type value as 0, it returns Red. But there
#is no value for type=0 in trimColor. It returns empty in the output.
