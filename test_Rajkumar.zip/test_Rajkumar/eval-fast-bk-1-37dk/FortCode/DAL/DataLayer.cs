﻿using FortCode.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace FortCode.DAL
{
    public class DataLayer
    {
        //string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
        public User LoginVerification(string UserName, string Password,string connectionString)
        {
            User objUser = new User();
            try
            {

                using (SqlConnection sqlconn_obj = new SqlConnection(connectionString))
                {
                    using (SqlCommand sqlcmd_obj = new SqlCommand("SP_CheckAuthentication", sqlconn_obj))
                    {
                        sqlcmd_obj.CommandType = CommandType.StoredProcedure;
                        sqlcmd_obj.Parameters.AddWithValue("@Email", UserName);
                        sqlcmd_obj.Parameters.AddWithValue("@Password", Password);
                        sqlconn_obj.Open();
                        SqlDataAdapter sqldap = new SqlDataAdapter(sqlcmd_obj);
                        DataTable resultdt = new DataTable();
                        sqldap.Fill(resultdt);
                        if (resultdt.Rows.Count > 0)
                        {
                            objUser.UserID = Convert.ToInt32(resultdt.Rows[0]["UserID"]);
                            objUser.Name = Convert.ToString(resultdt.Rows[0]["Name"]);
                            objUser.Email = Convert.ToString(resultdt.Rows[0]["Email"]);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
            }
            return objUser;
        }
        public City InsertCity(City objCity,string connectionString)
        {
            City obj_City = new City();
            try
            {
                using (SqlConnection sqlconn_obj = new SqlConnection(connectionString))
                {
                    using (SqlCommand sqlcmd_obj = new SqlCommand("SP_SaveCity", sqlconn_obj))
                    {
                        sqlcmd_obj.CommandType = CommandType.StoredProcedure;
                        sqlcmd_obj.Parameters.AddWithValue("@CityId", 0);
                        sqlcmd_obj.Parameters.AddWithValue("@CityName", objCity.CityName);
                        sqlcmd_obj.Parameters.AddWithValue("@Country", objCity.Country);                        
                        sqlconn_obj.Open();
                        int result = sqlcmd_obj.ExecuteNonQuery();
                        sqlconn_obj.Close();
                        if (result > 0)
                        {
                            obj_City.CityId = Convert.ToInt32(result);
                        }
                    }
                }
            }
            catch (Exception ex)
            {               
                throw;
            }
            return obj_City;
        }
        public List<City> GetAllCities(string connectionString)
        {
            List<City> lstCities = new List<City>();
            DataTable resultdt = new DataTable();

            try
            {
                using (SqlConnection sqlconn_obj = new SqlConnection(connectionString))
                {
                    using (SqlCommand sqlcmd_obj = new SqlCommand("SP_GetAllCities", sqlconn_obj))
                    {
                        sqlcmd_obj.CommandType = CommandType.StoredProcedure;
                        sqlconn_obj.Open();
                        SqlDataAdapter sqldap = new SqlDataAdapter(sqlcmd_obj);
                        sqldap.Fill(resultdt);
                        if (resultdt.Rows.Count > 0)
                        {
                            for (var i = 0; i < resultdt.Rows.Count; i++)
                            {
                                City objCity = new City();
                                objCity.CityId = resultdt.Rows[i]["CityId"] == DBNull.Value ? 0 : Convert.ToInt32(resultdt.Rows[i]["CityId"]);
                                objCity.CityName = Convert.ToString(resultdt.Rows[i]["CityName"]);
                                objCity.Country = Convert.ToString(resultdt.Rows[i]["Country"]);
                                lstCities.Add(objCity);
                            }
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                throw;
            }
            return lstCities;
        }
    }
}
