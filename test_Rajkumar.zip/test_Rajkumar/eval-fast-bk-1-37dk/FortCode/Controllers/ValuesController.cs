﻿using FortCode.DAL;
using FortCode.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace FortCode.Controllers
{
    [Authorize]
    [Route("values")]
   // [ApiController]
    public class ValuesController : ControllerBase
    {
        private IConfiguration Configuration;
        public ValuesController(IConfiguration _configuration)
        {
            Configuration = _configuration;
        }
        APIResponse ObjAPIResponse;
        [HttpGet]
        public HttpResponseMessage Get()
        {
            string connString = this.Configuration.GetConnectionString("DefaultConnection");
            ObjAPIResponse = new APIResponse();
            var resp = new HttpResponseMessage(HttpStatusCode.OK);
            try
            {
                DataLayer dal_obj = new DataLayer();
                List<City> lstCities = dal_obj.GetAllCities(connString);
                if (lstCities != null && lstCities.Count > 0)
                {
                    ObjAPIResponse.Object = (object)lstCities;
                    ObjAPIResponse.Result = true;
                    ObjAPIResponse.Message = "Success";
                }
                else
                {
                    ObjAPIResponse.Object = null;
                    ObjAPIResponse.Result = false;
                    ObjAPIResponse.Message = "No Records Found";
                }

                resp.Content = new StringContent(JsonConvert.SerializeObject(ObjAPIResponse));
                resp.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
            }
            catch (Exception ex)
            {
                ObjAPIResponse.Object = null;
                ObjAPIResponse.Result = false;
                ObjAPIResponse.Message = ex.Message;
                resp.Content = new StringContent(JsonConvert.SerializeObject(ObjAPIResponse));
                resp.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

            }
            return resp;
        }

        [HttpPost]     
        public HttpResponseMessage Post([FromBody]City obj)
        {
            string connString = this.Configuration.GetConnectionString("DefaultConnection");
            ObjAPIResponse = new APIResponse();
            var resp = new HttpResponseMessage(HttpStatusCode.OK);
            try
            {
                DataLayer dal_obj = new DataLayer();
                City resultobj = dal_obj.InsertCity(obj, connString);
                if (resultobj.CityId != 0)
                {
                    ObjAPIResponse.Object = (object)resultobj;
                    ObjAPIResponse.Result = true;
                    ObjAPIResponse.Message = "Success";
                }
                else
                {
                    ObjAPIResponse.Object = null;
                    ObjAPIResponse.Result = false;
                    ObjAPIResponse.Message = "Fail";
                }
                resp.Content = new StringContent(JsonConvert.SerializeObject(ObjAPIResponse));
                resp.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
            }
            catch (Exception ex)
            {
                ObjAPIResponse.Object = null;
                ObjAPIResponse.Result = false;
                ObjAPIResponse.Message =  ex.Message;
                resp.Content = new StringContent(JsonConvert.SerializeObject(ObjAPIResponse));
                resp.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
            }
            return resp;
        }
    }
}
