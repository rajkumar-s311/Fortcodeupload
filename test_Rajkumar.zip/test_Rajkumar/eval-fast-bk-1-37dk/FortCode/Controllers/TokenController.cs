﻿using Microsoft.AspNetCore.Mvc;
using FortCode.Models;
using FortCode.Helpers;
using Microsoft.AspNetCore.Authorization;
using FortCode.DAL;
using Microsoft.Extensions.Configuration;

namespace FortCode.Controllers
{
    [Route("token")]
    [AllowAnonymous]
    public class TokenController : Controller
    {
        private IConfiguration Configuration;
        public TokenController(IConfiguration _configuration)
        {
            Configuration = _configuration;
        }
        APIResponse ObjAPIResponse;

        [HttpPost]
        public IActionResult Create([FromBody] User inputModel)
        {
            string connString = this.Configuration.GetConnectionString("DefaultConnection");
            DataLayer dalObj = new DataLayer();
            User userobj = dalObj.LoginVerification(inputModel.Email,inputModel.Password,connString);
            if (userobj==null)
                return Unauthorized();
              
            var token = new JwtTokenBuilder()
                                .AddSecurityKey(JwtSecurityKey.Create("secret-key"))
                                .AddSubject("keys")
                                .AddIssuer("FortCode")
                                .AddAudience("FortCode")
                                .AddClaim("MembershipId", "111")
                                .AddExpiry(1)
                                .Build();

            //return Ok(token);
            return Ok(token.Value);
        }
    }
}
