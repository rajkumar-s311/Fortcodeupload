﻿using FortCode.DAL;
//using Microsoft.AspNetCore.Authentication;
using Microsoft.Owin.Security.OAuth;
using Microsoft.Owin.Security;
using Microsoft.Owin.Security.Cookies;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;


namespace FortCode.Providers
{
    public class OAuthProvider : OAuthAuthorizationServerProvider
    {
        #region Private Properties 
        private readonly string _publicClientId;
        #endregion

        #region Default Constructor method.  
        public OAuthProvider(string publicClientId)
        {
            if (publicClientId == null)
            {
                throw new ArgumentNullException(nameof(publicClientId));
            }
            _publicClientId = publicClientId;
        }

        #endregion

        #region Grant resource owner credentials override method.  
        public override async Task GrantResourceOwnerCredentials(OAuthGrantResourceOwnerCredentialsContext context)
        {           
            DataLayer objVMLogin = new DataLayer();
            string emailVal = context.UserName;
            string passwordVal = context.Password;
            var user = objVMLogin.LoginVerification(emailVal, passwordVal);          
            if (user == null)
            {
                context.SetError("invalid_grant", "The email or password is incorrect.");                  
                return;
            }
            if (user.UserID == 0)
            {
                context.SetError("invalid_grant", "The email or password is incorrect.");
                return;
            }
            var claims = new List<Claim>();
            var userInfo = user;
          
            claims.Add(new Claim(ClaimTypes.Name as string, user.Name));      

           
            ClaimsIdentity oAuthClaimIdentity = new ClaimsIdentity(claims, OAuthDefaults.AuthenticationType);
            ClaimsIdentity cookiesClaimIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationType);

            // Setting user authentication.  
            AuthenticationProperties properties = CreateProperties(userInfo.Name, userInfo.Email,userInfo.UserID);
            AuthenticationTicket ticket = new AuthenticationTicket(oAuthClaimIdentity, properties);

            // Grant access to authorize user.  
            context.Validated(ticket);
            context.Request.Context.Authentication.SignIn(cookiesClaimIdentity);
        }
        #endregion

        #region Token endpoint override method.  

        public override Task TokenEndpoint(OAuthTokenEndpointContext context)
        {
            foreach (KeyValuePair<string, string> property in context.Properties.Dictionary)
            {
                // Adding.  
                context.AdditionalResponseParameters.Add(property.Key, property.Value);
            }

            // Return info.  
            return Task.FromResult<object>(null);
        }

        #endregion

        #region Validate Client authntication override method  

        public override Task ValidateClientAuthentication(OAuthValidateClientAuthenticationContext context)
        {
            // Resource owner password credentials does not provide a client ID.  
            if (context.ClientId == null)
            {
                // Validate Authoorization.  
                context.Validated();
            }

            // Return info.  
            return Task.FromResult<object>(null);
        }

        #endregion

        #region Validate client redirect URI override method  

        public override Task ValidateClientRedirectUri(OAuthValidateClientRedirectUriContext context)
        {
            // Verification.  
            if (context.ClientId == _publicClientId)
            {
                // Initialization.  
                Uri expectedRootUri = new Uri(context.Request.Uri, "/");

                // Verification.  
                if (expectedRootUri.AbsoluteUri == context.RedirectUri)
                {
                    // Validating.  
                    context.Validated();
                }
            }

            // Return info.  
            return Task.FromResult<object>(null);
        }

        #endregion

        #region Create Authentication properties method.  

        public static AuthenticationProperties CreateProperties(string Name, string Email, int UserID)
        {
            // Settings.  
            IDictionary<string, string> data = new Dictionary<string, string>
                                               {
                                                     { "userID", Convert.ToString(UserID) },
                                                     { "name", Name },
                                                    {"email",Email }
                                               };

            // Return info.  
            return new AuthenticationProperties(data);
        }

        #endregion
    }
}
